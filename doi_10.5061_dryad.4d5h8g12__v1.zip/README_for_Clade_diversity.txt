File contains data used in:

Bergmann, PJ, Irschick, DJ. Vertebral evolution and the diversification of squamate reptiles. Published in Evolution.

Contact Philip J. Bergmann at pbergmann@clarku.edu with questions.


File contains two columns:
	-"Clade name" contains the name of each clade used in clade-level analyses.
	-"Number of Extant Species" contains the total number of described species, derived from the Reptile Online Database.

End
