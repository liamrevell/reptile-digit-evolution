File contains data used in:

Bergmann, PJ, Irschick, DJ. Vertebral evolution and the diversification of squamate reptiles. Published in Evolution.

Contact Philip J. Bergmann at pbergmann@clarku.edu with questions.


File contains 2 columns with vertebral count used in analyses for each species sampled:
	-"Species" is the species name.
	-"Presacral" is the number of presacral vertebrae for each species, counted from x-rays available at the MCZ, USNM, UMMZ, and FMNH, as well as compiled from literature sources, and x-rays from E. McElroy and M.C Brandley.

End
