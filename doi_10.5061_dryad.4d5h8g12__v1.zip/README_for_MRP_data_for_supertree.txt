File contains data used in:

Bergmann, PJ, Irschick, DJ. Vertebral evolution and the diversification of squamate reptiles. Published in Evolution.

Contact Philip J. Bergmann at pbergmann@clarku.edu with questions.


File contains:
	- The dataset obtained by coding published phylogenies into MRP format as a nexus file. 1 = species is descended from a node, 0 = species is not descended from a node, ? = species not included in analysis that included that node.

End
