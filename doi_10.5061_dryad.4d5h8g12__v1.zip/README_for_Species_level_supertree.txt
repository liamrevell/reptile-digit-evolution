File contains data used in:

Bergmann, PJ, Irschick, DJ. Vertebral evolution and the diversification of squamate reptiles. Published in Evolution.

Contact Philip J. Bergmann at pbergmann@clarku.edu with questions.


File contains:
	- The species-level supertree of the Squamata used in species-level analyses, dating using sequences for 30 genes or gene fragments and 26 fossil taxa. Tree is in Newick format and contains branch lengths in millions of years and node numbers.

End
