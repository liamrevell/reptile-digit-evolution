File contains data used in:

Bergmann, PJ, Irschick, DJ. Vertebral evolution and the diversification of squamate reptiles. Published in Evolution.

Contact Philip J. Bergmann at pbergmann@clarku.edu with questions.


File contains:
	- The clade-level supertree of the Squamata used in clade-level analyses. Tree is in Newick format and contains branch lengths in millions of years and node numbers that correspond to the species level-supertree.

End
